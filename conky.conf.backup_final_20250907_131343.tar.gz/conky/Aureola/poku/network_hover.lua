-- authored by 0hex01
-- Simple network info function for Conky
function conky_network_info()
    -- Get network interfaces info
    local handle = io.popen('ip -br -c addr show | grep -v "lo\\|link" | awk ''{print $1 " " $3 " " $4}''')
    local result = handle:read("*a")
    handle:close()
    
    if result and result ~= "" then
        return result
    end
    return "No network interfaces found"
end
