-- Clock and Power Rings
-- Clock and Power Rings by londonali1010 (2009)
-- Modified for Conky 1.10.0+
-- Added Power Ring by Cascade

-- Configuration
local settings_table = {
    {
        -- Power Ring (outermost)
        name="exec",
        arg="cat /tmp/power_usage 2>/dev/null || echo 0",
        max=45,  -- Max 45W
        bg_color=0x333333,    -- Dark gray background
        bg_alpha=0.3,
        fg_color=0xFF0000,    -- Bright Red color for power
        fg_alpha=0.9,
        x=100, y=100,         -- Position
        radius=50,
        thickness=8,          -- Thickness of the ring
        start_angle=0,
        end_angle=360
    },
    {
        -- Hours ring (middle)
        name="time",
        arg="%I",
        max=12,
        bg_color=0x1a3300,    -- Dark green background
        bg_alpha=0.3,
        fg_color=0x99ff66,    -- Light green
        fg_alpha=0.8,
        x=60, y=60,
        radius=35,
        thickness=5,
        start_angle=0,
        end_angle=360
    },
    {
        -- Minutes ring (inner)
        name="time",
        arg="%M",
        max=60,
        bg_color=0x1a3300,    -- Dark green background
        bg_alpha=0.3,
        fg_color=0x66cc33,    -- Medium green
        fg_alpha=0.8,
        x=60, y=60,
        radius=20,
        thickness=5,
        start_angle=0,
        end_angle=360
    }
}

-- Helper functions
function rgb_to_r_g_b(color, alpha)
    return ((color / 0x10000) % 0x100) / 255.,
           ((color / 0x100) % 0x100) / 255.,
           (color % 0x100) / 255.,
           alpha
end

function draw_ring(cr, t, pt)
    local w, h = conky_window.width, conky_window.height
    local xc, yc, ring_r, ring_w, sa, ea = pt["x"], pt["y"], pt["radius"], pt["thickness"], pt["start_angle"], pt["end_angle"]
    local bgc, bga, fgc, fga = pt["bg_color"], pt["bg_alpha"], pt["fg_color"], pt["fg_alpha"]

    local angle_0 = sa * (2 * math.pi / 360) - math.pi / 2
    local angle_f = ea * (2 * math.pi / 360) - math.pi / 2
    local t_arc = t * (angle_f - angle_0)

    -- Draw background ring
    cairo_arc(cr, xc, yc, ring_r, angle_0, angle_f)
    cairo_set_source_rgba(cr, rgb_to_r_g_b(bgc, bga))
    cairo_set_line_width(cr, ring_w)
    cairo_stroke(cr)
    
    -- Draw indicator ring
    cairo_arc(cr, xc, yc, ring_r, angle_0, angle_0 + t_arc)
    cairo_set_source_rgba(cr, rgb_to_r_g_b(fgc, fga))
    cairo_stroke(cr)
end

function conky_clock_rings()
    local function setup_rings(cr, pt)
        local str = ""
        local value = 0
        
        str = string.format("${%s %s}", pt["name"], pt["arg"])
        str = conky_parse(str)
        
        value = tonumber(str)
        if value == nil then 
            -- Try to get a default value if reading fails
            if pt["name"] == "exec" then
                value = 0
            else
                value = 0
            end
        end
        
        -- For power ring, ensure value is within bounds
        if pt["name"] == "exec" then
            if value > pt["max"] then value = pt["max"] end
            if value < 0 then value = 0 end
        end
        
        local pct = value / pt["max"]
        if pct > 1 then pct = 1 end
        if pct < 0 then pct = 0 end
        
        draw_ring(cr, pct, pt)
    end
    
    -- Only run if we have a display
    if conky_window == nil then return end
    
    local cs = cairo_xlib_surface_create(conky_window.display, conky_window.drawable, conky_window.visual, conky_window.width, conky_window.height)
    local cr = cairo_create(cs)
    
    local updates = tonumber(conky_parse("${updates}"))
    if updates > 5 then
        for i in pairs(settings_table) do
            setup_rings(cr, settings_table[i])
        end
    end
    
    cairo_destroy(cr)
    cairo_surface_destroy(cs)
    cr = nil
end
