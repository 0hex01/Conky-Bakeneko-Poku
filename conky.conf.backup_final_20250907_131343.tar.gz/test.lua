-- Simple test Lua script for Conky
function conky_test()
    return "Lua is working!"
end
